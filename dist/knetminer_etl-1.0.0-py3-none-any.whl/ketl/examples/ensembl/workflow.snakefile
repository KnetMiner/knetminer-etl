# Requires tests/ in PYTHONPATH
import asyncio

# Local modules require that you do something like pointing PYTHONPATH to 
# $(dirname workflow.snakefile)
import wf_config
from brandizpyes.logging import logger_config
from pyspark.sql.functions import lit
from wf_mapping import (
	E2U_ENSEMBL_GENE_ACCESSION_MAPPERS, E2U_ENSEMBL_GENE_MAPPER,
	E2U_ENSEMBL_PROTEIN_MAPPER, E2U_GENE2PROTEIN_MAPPER,
	E2U_UNIPROT_ACCESSION_MAPPERS, NEO_LOADER_CONFIG)

from ketl.config import load_config
from ketl.core import PGElementType
from ketl.io.core import pg_df_2_pg_jsonl, triples_2_pg_df
from ketl.io.neoloader import (async_pg_jsonl_neo_loader,
                               create_neo_driver_from_config,
                               pg_jsonl_neo_loader)
from ketl.spark.utils import (create_spark_session_from_config, df_check_path,
                              df_path, df_save, df_union_all_by_name)

# TODO: ketl logging

my_dir = os.path.realpath ( workflow.basedir )

KETL_DATA = os.getenv ( "KETL_DATA", my_dir + "/data" )
KETL_IN = os.getenv ( "KETL_IN", my_dir + "/data/input" )
KETL_OUT = os.getenv ( "KETL_OUT", KETL_DATA + "/output" )
KETL_TMP = os.getenv ( "KETL_TMP", KETL_DATA + "/tmp" )

log_cfg_path = os.path.realpath ( my_dir + "/logging.yml" )
logger_config ( cfg_path = str ( log_cfg_path ) )


# As said in wf_config, this is an alternative way to configure
# config = load_config ( my_dir / "config.yml" )
# spark_session = create_spark_session_from_config ( config.get ( "spark" ) )
# neo_driver = create_neo_driver_from_config ( config.get ( "neo4j" ) )
# neo_loader_config = NeoLoaderConfig.from_config ( config.get ( "neoloader" ) )

rule all:
	"""
	Loads the final JSONL file into Neo4j, using the NeoLoader.

	This just triggers the neo_loader rule for nodes and edges.
	"""
	input:
		f"{KETL_TMP}/knowledge-graph.done.edges"


rule neo_loader:
	"""
	Loads the final JSONL file into Neo4j, using the NeoLoader.

	This loads nodes and edges with 2 separate rule instantiations, triggered by 
	the wildcard expansion in all.
	"""
	
	input:
		f"{KETL_OUT}/knowledge-graph.json"
	output:
		f"{KETL_TMP}/knowledge-graph.done.edges"
	run:
		pg_jsonl_neo_loader (
			pg_jsonl_source = Path ( input[0] ),
			done_base_path = output[0],
			neo_driver = wf_config.create_neo4j_driver (),
			config = NEO_LOADER_CONFIG
		)			


rule triples_2_json_pg:
	"""
	Builds the knowledge graph in PG/JSONL format, which is the format expected by the NeoLoader.

	Here, we do this by merging all the dataset triples built from various mappers and then converting
	the merge.

	If you have very big triple DFs, you might want to split this into further rules and save intermediate
	parquet files, using triples_2_pg_df() and df_save().
	"""
	input:
		# The PG builder needs to distinguish between nodes and edges, see below
		nodes = [
			df_check_path ( f"{KETL_TMP}/gene-triples.parquet" ),
			df_check_path ( f"{KETL_TMP}/gene-accession-triples.parquet" ),
			df_check_path ( f"{KETL_TMP}/protein-triples.parquet" ),
			df_check_path ( f"{KETL_TMP}/protein-accession-triples.parquet" )
		],
		edges = [
			df_check_path ( f"{KETL_TMP}/gene-accession-links-triples.parquet" ),
			df_check_path ( f"{KETL_TMP}/protein-accession-links-triples.parquet" ),
			df_check_path ( f"{KETL_TMP}/gene2protein.parquet" )
		]
	output:
		f"{KETL_OUT}/knowledge-graph.json"
	run:
		# Work out nodes together and then edge together
		with wf_config.get_spark_session ( rule ) as spark_session:
			all_triples_df = df_union_all_by_name ( *input.nodes, *input.edges, spark = spark_session )

			# Then turn it all into PG
			pg_df = triples_2_pg_df ( all_triples_df, spark = spark_session )
			pg_df_2_pg_jsonl ( pg_df, spark_session, output[0] )


rule map_ensembl_plants_genes:
	"""
	Maps the TSV input to gene node triples and other related PG triples, such as accession
	nodes and edges.
	"""
	input:
		f"{KETL_IN}/ensembl-uniprot-genes.tsv"
	output:
		df_check_path ( f"{KETL_TMP}/gene-triples.parquet" ),
		df_check_path ( f"{KETL_TMP}/gene-accession-triples.parquet" ),
		df_check_path ( f"{KETL_TMP}/gene-accession-links-triples.parquet" )
	run:
		# TODO: blah, move it to an helper getting input, list[mapper, out_path]
		#
		with wf_config.get_spark_session ( rule ) as spark_session:
			E2U_ENSEMBL_GENE_MAPPER.map ( spark_session, input[0], out_path = output[0] )
			# These have node/edge mappers
			E2U_ENSEMBL_GENE_ACCESSION_MAPPERS [ 0 ].map ( spark_session, input[0], out_path = output[1] )
			E2U_ENSEMBL_GENE_ACCESSION_MAPPERS [ 1 ].map ( spark_session, input[0], out_path = output[2] )


rule map_ensembl_plants_proteins:
	"""
	Maps the TSV input to protein triples and other related PG triples, such as accession 
	nodes and edges.
	"""
	input:
		f"{KETL_IN}/ensembl-uniprot-genes.tsv"
	output:
		df_check_path ( f"{KETL_TMP}/protein-triples.parquet" ),
		df_check_path ( f"{KETL_TMP}/protein-accession-triples.parquet" ),
		df_check_path ( f"{KETL_TMP}/protein-accession-links-triples.parquet" )

	run:
		with wf_config.get_spark_session ( rule ) as spark_session:
			E2U_ENSEMBL_PROTEIN_MAPPER.map ( spark_session, input[0], out_path = output[0] )
			E2U_UNIPROT_ACCESSION_MAPPERS [ 0 ].map ( spark_session, input[0], out_path = output[1] )
			E2U_UNIPROT_ACCESSION_MAPPERS [ 1 ].map ( spark_session, input[0], out_path = output[2] )


rule map_ensembl_plants_encodes:
	"""
	Maps the TSV input to gene-to-protein triples.
	"""
	input:
		f"{KETL_IN}/ensembl-uniprot-genes.tsv"
	output:
		df_check_path ( f"{KETL_TMP}/gene2protein.parquet" )
	run:
		# Closing the session allows for clean operations.
		# Giving it a distinct app name has a few benefits, such as better logging.
		with wf_config.get_spark_session( rule ) as spark_session:
			E2U_GENE2PROTEIN_MAPPER.map ( spark_session, input[0], out_path = output[0] )
